print("Hi my name is Mudather Zeinelabeen")
print("Iam a teacher as well as a researcher at John Ruskin College")
print("I have just started working at this college about a couple of months ago")